package com.company.Commands;

import com.company.Command;

public class Exist extends Command {
    @Override
    public void Execute() throws Exception {

    }
}
