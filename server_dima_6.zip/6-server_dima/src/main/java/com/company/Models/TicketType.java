package com.company.Models;

public enum TicketType {
    VIP,
    USUAL,
    BUDGETARY,
    CHEAP;
}