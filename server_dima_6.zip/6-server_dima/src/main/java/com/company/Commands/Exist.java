package com.company.Commands;

import com.company.Command;

public class Exist extends Command {
    @Override
    public void Execute(boolean is_thread) throws Exception {

    }
}
